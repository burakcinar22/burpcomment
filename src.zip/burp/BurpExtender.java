package burp;

import java.awt.Component;
import java.io.PrintWriter;
import mygui.GuiExtender;
import mygui.GuiExtenderProfile;


public class BurpExtender implements IBurpExtender, ITab,IHttpListener {
    public static PrintWriter stdout;
    public static PrintWriter stderr;
    private IContextMenuInvocation mInvocation;

    public static IExtensionHelpers helpers;

    public void registerExtenderCallbacks(IBurpExtenderCallbacks callbacks) {
        GuiExtender.callbacks = callbacks;
        callbacks.setExtensionName(GuiExtender.extensionName);
        GuiExtender.MyGui = new GuiExtenderProfile();
   
        this.helpers = callbacks.getHelpers();
        
        callbacks.registerHttpListener(this);
        stdout = new PrintWriter(callbacks.getStdout(),true);
        stderr = new PrintWriter(callbacks.getStderr(),true);
        
        callbacks.addSuiteTab(this);
    }

    @Override
    public String getTabCaption() {
        return GuiExtender.extensionName;
    }

    @Override
    public Component getUiComponent() {
        return GuiExtender.MyGui;
    }

    @Override
    public void processHttpMessage(int toolFlag, boolean messageIsRequest, IHttpRequestResponse messageInfo) {
            //IRequestInfo reqInfo = helpers.analyzeRequest(messageInfo.getRequest());
       
       if ((toolFlag == 4)){
            
            //stdout.println("deneme");
            
            IHttpService httpservice=messageInfo.getHttpService();
             byte[] req = messageInfo.getRequest();
            String url=this.helpers.analyzeRequest(messageInfo).getUrl().toString();
            IRequestInfo requestInfo = helpers.analyzeRequest(httpservice,req);
            String reqstr=new String(messageInfo.getRequest());

            String response = new String(messageInfo.getResponse());
            
            
            
            if(response!=""){
                GuiExtender.MyGui.comment_add(url,response);
            }
            
        }  
        }
    
    public static IBurpExtenderCallbacks getBurpCallbacks() {
        return GuiExtender.callbacks;
    }

 
}

