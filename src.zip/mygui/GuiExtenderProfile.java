package mygui;

import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.swing.SwingUtilities;


 public class GuiExtenderProfile extends javax.swing.JPanel {

    static String xy;

    public GuiExtenderProfile() {
        initComponents();
       
    }

    
  
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel2 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();

        jTextArea1.setColumns(20);
        jTextArea1.setRows(5);
        jScrollPane1.setViewportView(jTextArea1);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 1400, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 590, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(299, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
    }// </editor-fold>//GEN-END:initComponents

    
 public static void comment_add(final String url,final String source) {
 xy = "";

 Pattern pattern = Pattern.compile("<!--(.*?)-->");
 Matcher matcher = pattern.matcher(source);
 

 while (matcher.find()) {
      // Get the matching string
      xy += matcher.group()+"\n";
    }
 
  SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                if(xy.length()>3) {
                    
                     jTextArea1.append("URL:"+url+ " \n ----------------------------------------------------- "+xy+"\n");

                }
            }
        });
 

 
 

 
 
}


 
    /*
    
    
    SwingUtilities.invokeLater(new Runnable()
        {
            @Override
            public void run()
            {
                replicatorMenu = new burp.Menu(BurpExtender.this);
                replicatorMenu.setViewType(viewType);
                burpMenuBar = getBurpFrame().getJMenuBar();
                burpMenuBar.add(replicatorMenu);
                setViewType(viewType);
            }
        });
    */




    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    public static final javax.swing.JTextArea jTextArea1 = new javax.swing.JTextArea();
    // End of variables declaration//GEN-END:variables

 

}

