package mygui;

import burp.IBurpExtenderCallbacks;


public class GuiExtender {

    public static IBurpExtenderCallbacks callbacks;
    public static GuiExtenderProfile MyGui;
    public static String extensionName = "Burp Comment";
}







   
